function showtime() {
		var today = new Date((new Date()).getTime());
 
		var hour = today.getHours();
		var minute = today.getMinutes();
		var second = today.getSeconds();
		if (hour <= 9)
			hour = "0" + hour;
		if (minute <= 9)
			minute = "0" + minute;
		if (second <= 9)
			second = "0" + second;
		      
		var utc = today.getTime() + (today.getTimezoneOffset() * 60000);
		var bjDate = new Date(utc + (3600000 * (8)));
		
		var ldDate = new Date(utc + (3600000 * (0)));
		var nyDate = new Date(utc + (3600000 * (-4)));
		var tyDate = new Date(utc + (3600000 * (9)));
		var sxDate = new Date(utc + (3600000 * (2)));
		
		
		var adDate = new Date(utc + (3600000 * (11)));
		var mxDate = new Date(utc + (3600000 * (1)));
		
		var bjhour = bjDate.getHours() < 9 ? ("0" + bjDate.getHours()) : bjDate.getHours();
 
		var ldhour = ldDate.getHours() < 9 ? ("0" + ldDate.getHours()) : ldDate.getHours();
		var nyhour = nyDate.getHours() < 9 ? ("0" + nyDate.getHours()) : nyDate.getHours();
		var tyhour = tyDate.getHours() < 9 ? ("0" + tyDate.getHours()) : tyDate.getHours();
		var sxhour = sxDate.getHours() < 9 ? ("0" + sxDate.getHours()) : sxDate.getHours();
		
		
		var adhour = adDate.getHours() < 9 ? ("0" + adDate.getHours()) : adDate.getHours();
		var mxhour = mxDate.getHours() < 9 ? ("0" + mxDate.getHours()) : mxDate.getHours();
				
		var strbjdtime = bjhour + ":" + minute + ":" + second + "&#160;";		
		
		var strldtime = ldhour + ":" + minute + ":" + second + "&#160;";
		var strnytime = nyhour + ":" + minute + ":" + second + "&#160;";
		var strtytime = tyhour + ":" + minute + ":" + second + "&#160;";
 
		var straddtime = adhour + ":" + minute + ":" + second + "&#160;";
		var strmxdtime = mxhour + ":" + minute + ":" + second + "&#160;";		
		var strsxtime = sxhour + ":" + minute + ":" + second;
		
		var strhktime = hour + ":" + minute + ":" + second + "&#160;";
		
		document.getElementById('addtime').innerHTML = straddtime;
		
		document.getElementById('bjdtime').innerHTML = strbjdtime;
 
		document.getElementById('ldtime').innerHTML = strldtime; 
		document.getElementById('nytime').innerHTML = strnytime;
		document.getElementById('tytime').innerHTML = strtytime;
		
		
		document.getElementById('mxdtime').innerHTML = strmxdtime;
 
		
		
		setTimeout("showtime();", 500); 
		return (today.getTime());
}
showtime();
